
import os
import sys
import supervisor
supervisor.disable_autoreload()

def path_exists(p):
    try:
        os.stat(p)
    except OSError as e:
        return False
    return True

def path_join(parent: str, child: str):
    parent = parent.rstrip("/")
    child = child.strip("./")
    return os.sep.join((parent, child))

def run_app(app_dir):
    if path_exists(path_join(app_dir,"code.mpy")):
       sys.path.insert(0, path_join(app_dir,"lib"))
       sys.path.insert(0, app_dir)
       import code
       code.main()


run_app("/app")
#run_app("/updator")
